package mk.ukim.finki.wp.lab.web.controller;

public class ArtistController {
}
